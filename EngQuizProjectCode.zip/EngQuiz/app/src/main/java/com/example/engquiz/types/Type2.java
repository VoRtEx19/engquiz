package com.example.engquiz.types;

public class Type2 {
    private String q;
    private String[] a;
    private int ra;


    public String getQ() {
        return q;
    }

    public String[] getA() { return a; }

    public int getRa() {
        return ra;
    }


    public void setQ(String q) {
        this.q = q;
    }

    public void setA(String[] a) {
        this.a = a;
    }

    public void setRa(int ra) {
        this.ra = ra;
    }
}
